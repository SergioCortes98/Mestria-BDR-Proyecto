<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1751813455191'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/var/jenkins_home/jobs/DBeaverDesktop/jobs/dbeaver-ce/workspace/dbeaver/product/community/target/products/org.jkiss.dbeaver.core.product/win32/win32/x86_64/dbeaver'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/var/jenkins_home/jobs/DBeaverDesktop/jobs/dbeaver-ce/workspace/dbeaver/product/community/target/products/org.jkiss.dbeaver.core.product/win32/win32/x86_64/dbeaver'/>
  </properties>
</profile>
